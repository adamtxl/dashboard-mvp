// import colors from 'tailwindcss/colors'

// export default {
//   content: [
//     './index.html',
//     './src/**/*.{js,ts,jsx,tsx}', // 👈 Tells Tailwind where to scan for classnames
//   ],
//   theme: {
//     extend: {
//       colors,
//     },
//   },
//   plugins: [],
// }
