// src/main.jsx
import './chartConfig'; // Changed from '../chartConfig.js' to './chartConfig'
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App.jsx';

console.log("🚀 Chart.js fully registered");

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>
);
