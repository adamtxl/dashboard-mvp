// src/chartConfig.js
import { 
  Chart as ChartJS,
  LineElement,
  BarElement,
  CategoryScale,
  LinearScale,
  TimeScale, // Must be explicitly imported
  PointElement,
  Tooltip,
  Legend,
} from 'chart.js';
import 'chartjs-adapter-date-fns'; // Required for time scale
import annotationPlugin from 'chartjs-plugin-annotation';

// SINGLE register call with all elements
ChartJS.register(
  LineElement,
  BarElement,
  CategoryScale,
  LinearScale,
  TimeScale, // Must be registered here
  PointElement,
  Tooltip,
  Legend,
  annotationPlugin
);